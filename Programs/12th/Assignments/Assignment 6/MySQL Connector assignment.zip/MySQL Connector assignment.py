import mysql.connector

con=mysql.connector.connect(host='localhost',user='root',passwd='qwerty11235',database='school')

def view_data(var1):
    var1.execute('SELECT * from employee')
    res=var1.fetchall()
    for i in res:
        print('Last Name=',i[1],'Title=',i[2],'Manager=',i[3],'Department=',i[4],'Monthly Salary=',i[5],'Annual Salary=',i[6],sep=' ',end='\n')

def add_new(var1,details):
    sql_insert="insert into employee values %s"%(details)
    var1.execute(sql_insert)
    con.commit()
    
def update_manager(var1,var2,var3):
    sql_up_man="update employee set Manager='%s' where Manager like '%s'"%(var3,var2)
    var1.execute(sql_up_man)
    con.commit()

def update_dep(var1,var2,var3):
    sql_up_dep="update employee set Department='%s' where Department like '%s'"%(var3,var2)
    var1.execute(sql_up_dep)
    con.commit()

def update_sal(var1,var2,var3):
    sql_up_sal="update employee set Monthly_Salary='%s' where Last_Name='%s'"%(str(var3),var2)
    sql_up_sal2="update employee set Annual_Salary='%s' where Monthly_Salary like '%s'"%(str(var3*12),var3)
    var1.execute(sql_up_sal)
    var1.execute(sql_up_sal2)
    con.commit()

def delete(var1,name):
    sql_del="delete from employee where Last_Name like '%s'"%(name)
    var1.execute(sql_del)
    con.commit()

def find_emp(var1,name):
    sql_find="select * from employee where Last_Name like '%s'"%(name)
    var1.execute(sql_find)
    rows=var1.fetchall()
    print(rows)

def get_uni(var):
    sql_dep='select count(distinct Department) from employee'
    sql_emp='select count(ID) from employee'
    var.execute(sql_dep)
    r=var.fetchall()[0][0]
    print('There are',r,'unique departments')
    var.execute(sql_emp)
    r=var.fetchall()[0][0]
    print('There are',r,'employees')


def find_max(var):
    sql_dep='select max(Annual_Salary) from programmer'
    var.execute(sql_dep)
    r=var.fetchall()[0]
    print('The maximum salary of any programmer is',r)

concur=con.cursor()

if con.is_connected():
    x=input('Do you want to:\n'
            '1. View all records\n'
            '2. Add a new employee to the table\n'
            '3. Update details\n'
            '4. Delete a user\n'
            '5. Search for an employee\n')

    if x=='1':
        
        view_data(concur)
        
    if x=='2':

        y=input('enter new employee details as a tuple ')
        add_new(concur,y)

    if x=='3':

        x1=input('Do you want to update:\n'
                 'a. Manager\n'
                 'b. Department\n'
                 'c. Salary\n')
        if x1=='a':

            y=input('enter the manager to be updated ')
            y2=input('enter updated manager ')
            update_manager(concur,y,y2)

        if x1=='b':
            y=input('enter the department to be updated ')
            y2=input('enter updated department ')
            update_dep(concur,y,y2)

        if x1=='c':

            y=input('enter the employee\'s salary to be updated ')
            y2=int(input('enter updated salary '))
            update_sal(concur,y,y2)
    if x=='4':

        y=input('enter employee to be deleted ')
        delete(concur,y)

    if x=='5':

        y=input('enter employee to find ')
        find_emp(concur,y)


#2

    get_uni(concur)


#3

    try:
    
        create_tab="create table programmer as(select * from employee where Title='Programmer')"
        concur.execute(create_tab)
    except:
        print('The table already exists/does not exist')
        
    find_max(concur)

    con.close()


else:
    print('connection not establised')
