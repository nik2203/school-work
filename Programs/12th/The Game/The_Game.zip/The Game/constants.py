WINDOW_SIZE = 255
TL = 8 # Tile length
TN = 32 # Number of tiles
COL_KEY = 15
DEBUGGING = False
