# RUN:

python3 platformer.py

# Requirements:

Pyxel 1.3.3
